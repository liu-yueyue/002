const envList = [{"envId":"cloud1-9g5m0zh073a28414","alias":"cloud1"},{"envId":"lyy-8gvjdkm2e8bc3a4c","alias":"lyy"}]
const isMac = false
module.exports = {
    envList,
    isMac
}